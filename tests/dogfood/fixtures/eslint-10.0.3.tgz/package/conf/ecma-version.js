/**
 * @fileoverview Configuration related to ECMAScript versions
 * @author Milos Djermanovic
 */

"use strict";

/**
 * The latest ECMAScript version supported by ESLint.
 * @type {number} year-based ECMAScript version
 */
const LATEST_ECMA_VERSION = 2026;

module.exports = {
	LATEST_ECMA_VERSION,
};
