export*from"lit-html/directives/unsafe-mathml.js";
//# sourceMappingURL=unsafe-mathml.js.map
