# Current-main resolver composition qualification

Fixed canonical main/control HEAD: `e5605c8c0fb6b42ce29fe8aad7165cf168108c1c`.
Incoming published checkpoint: `75c98267d4aabba2f78238f292e0e7c2eb6554f3`.
Candidate ran at actual HEAD e560 with the frozen ordinary merge overlay; control
ran at e560 with only the byte-identical existing regression added. Full dirty
receipts and complete source/test/config and selected dependency input hashes
are in each epoch receipt. Installed Node25.9.0/V8 14.1.146.11-node.25,
empty NODE_OPTIONS; unchanged single-fork69-case command, no external deadline.

Both corrected arms exit0,69/69 across four files, zero skips/todos/failures.
All13 full named observations,16 validated full binaries and10 full memory
witnesses exactly match. `compare-current.py` separately pins the new epoch;
the historical archived comparator and instrument remain unchanged. It checks
full before/after input population equality (the successful exact re-enumeration
receipt is retained as epoch-after-full), the exact four authorized path
differences, matching test/config/selected dependency hashes and common
provenance. `validate-binaries.mjs` independently validates all16 Wasm binaries
in each arm. Dependency custody is selected inputs, not all node_modules.

The first69/69 epoch is preserved in `epoch-v1`; its scratch full-input generator
omitted the control's untracked test from the manifest despite the runtime's
provenance hash. That manifest is not accepted as full custody. Both corrected
arms were executed again after fixing the scratch path filter.

Canonical inventory exits0 against explicit e560:1907 tracked modules and3
nonmodules, versus1906 and2 on matching main; errors empty, architecture and
graph remain incomplete. Exact copied-policy omission controls produce the
required1/2/3 nonmodule/module/target errors. Removing the two authorized rows
recovers the entire canonical policy byte for byte and parsed ordered data.
Strict source+test typing, format/lint, dialect/flat directory, exact-base
LOC/function budgets, coercion/oracle/dead-export/import-cycle checks exit0;
matching control strict source+test typing exits0. Ordinary conflict resolution
was staged only after frozen runtime custody verification.

Normal default-heap build exits0 under installed Node25.9: Vite, declaration
pruning, test262 CLI/worker all complete. Historical Node22 exit134 failures
remain preserved; this actual new-epoch result does not rewrite those failures.
No native migration/retirement credit, public push/PR/comment, HOLD/queue change
or final A integration authority is inferred. Normal hooks and exact-head CI
remain before publication/delivery.

The comparison scratch writer was then made non-destructive: future replays
write a separate after receipt and cannot replace the immutable before receipt.
This artifact-safety edit changes no input, runtime observation or comparison
assertion. Successful equality preceded staging; staged custody is separate.
