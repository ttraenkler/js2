import {readFileSync} from 'node:fs';
import assert from 'node:assert/strict';
for(const folder of ['.','../codex-6914-current-control-20261011-01a12827']){
 let n=0;
 const inspect=value=>{if(!value||typeof value!=='object')return;if(Object.hasOwn(value,'binaryBase64')){assert.equal(WebAssembly.validate(new Uint8Array(Buffer.from(value.binaryBase64,'base64'))),true);n++;}for(const child of Object.values(value))inspect(child);};
 for(const line of readFileSync(folder+'/.tmp/current-registry/runtime.log','utf8').split('\n'))if(line.startsWith('{"issue":6914,'))inspect(JSON.parse(line));
 assert.equal(n,16);
}
console.log(JSON.stringify({independentlyValidatedBinariesPerArm:16}));
