import json,hashlib,base64,subprocess,os
from pathlib import Path
root=Path.cwd();control=root.parent/'codex-6914-current-control-20261011-01a12827';arms=[];receipts=[];provenances=[]
expected_ids=["source-alias31","source-push31","source-alias-push21","source-import-custody","resolve-zero-hop","resolve-one-hop","resolve-three-hop","legacy-u8-forwarded","registration-array-first","registration-u8-first","installed-exact-body-abi","import-offset-artifact","fresh-object-custody"]
for folder in [control,root]:
 p=folder/'.tmp/current-registry';receipt=json.loads((p/'epoch-before.json').read_text());receipts.append(receipt);assert receipt['head']=='e5605c8c0fb6b42ce29fe8aad7165cf168108c1c';before_population=set(receipt['inputs']);subprocess.run(['python3','.tmp/current-registry/freeze.py'],cwd=folder,check=True,env=dict(os.environ,JS2WASM_EPOCH_OUTPUT='.tmp/current-registry/epoch-after-full.json'));relisted=json.loads((p/'epoch-after-full.json').read_text());assert relisted==receipt;after={name:hashlib.sha256((folder/name).read_bytes()).hexdigest() for name in receipt['inputs']};assert after==receipt['inputs'];assert subprocess.check_output(['git','status','--short'],cwd=folder).decode()==receipt['dirty'];(p/'epoch-after.json').write_text(json.dumps({'inputsUnchanged':True,'dirtyUnchanged':True,'inputCount':len(after)},indent=2))
 rows=[json.loads(s) for s in (p/'runtime.log').read_text().splitlines() if s.startswith('{"issue":6914,')];assert len(rows)==14;provenance=[r for r in rows if r['kind']=='provenance'];assert len(provenance)==1;prov=provenance[0];assert prov['head']==receipt['head'];assert prov['dirty']==receipt['dirty'];assert prov['testSha256']==receipt['inputs']['tests/issue-6914-linear-ir-array-forwarding-provider-body.test.ts'];assert prov['runtimeSha256']==receipt['inputs']['src/codegen-linear/runtime.ts'];obs=[r for r in rows if r['kind']=='observation'];assert len(obs)==13;assert sorted(r['id'] for r in obs)==sorted(expected_ids);provenances.append(prov)
 counts={'binaries':0,'memories':0}
 def inspect(v):
  if isinstance(v,dict):
   if 'binaryBase64' in v:
    b=base64.b64decode(v['binaryBase64']);assert len(b)==v['byteLength'];assert hashlib.sha256(b).hexdigest()==v['sha256'];assert v['valid'];counts['binaries']+=1
   if 'memoryBase64' in v:
    b=base64.b64decode(v['memoryBase64']);assert len(b)==v['memoryBytes'];assert hashlib.sha256(b).hexdigest()==v['memorySha256'];counts['memories']+=1
   for val in v.values():inspect(val)
  elif isinstance(v,list):
   for val in v:inspect(val)
 for row in obs:assert row['status']=='passed' and row['failure'] is None;inspect(row['evidence'])
 assert counts=={'binaries':16,'memories':10}
 report=json.loads((p/'report.json').read_text());assert report['numTotalTests']==report['numPassedTests']==69;assert report['numFailedTests']==report['numPendingTests']==report['numTodoTests']==0;assert len(report['testResults'])==4
 cases=sorted([{'name':t['fullName'],'status':t['status'],'failures':t['failureMessages']} for f in report['testResults'] for t in f['assertionResults']],key=lambda t:t['name']);assert len(cases)==len({t['name'] for t in cases})==69;assert all(t['status']=='passed' and t['failures']==[] for t in cases);arms.append({'observations':obs,'cases':cases})
assert arms[0]==arms[1]
a,b=receipts
allowed={'src/codegen-linear/runtime.ts','src/codegen-linear/runtime/arrays/forwarding-resolver.ts','src/codegen-linear/runtime/arrays/README.md','scripts/compiler-boundaries.json'}
assert set(a['inputs'])^set(b['inputs'])=={'src/codegen-linear/runtime/arrays/forwarding-resolver.ts','src/codegen-linear/runtime/arrays/README.md'}
differences={key for key in set(a['inputs'])|set(b['inputs']) if a['inputs'].get(key)!=b['inputs'].get(key)};assert differences==allowed
assert a['selectedDependencies']==b['selectedDependencies'];assert a['node']==b['node'];assert a['command']==b['command'];assert a['nodeOptions']==b['nodeOptions']==''
assert (control/'.tmp/current-registry/tsconfig.test-inclusive.json').read_bytes()==(root/'.tmp/current-registry/tsconfig.test-inclusive.json').read_bytes()
for key in ['baseline','testSha256','layoutSha256','sourceFixtures','node','v8','nodeOptions','linearIrFlag','command','deadline','expectedObservations','ids','execArgv','argv']:
 assert provenances[0][key]==provenances[1][key],key

print(json.dumps({'cases':69,'files':4,'observations':13,'binariesPerArm':16,'fullMemoriesPerArm':10,'exactObservationAndCaseEquality':True,'fullEpochInputsUnchanged':True},indent=2))
