import { writeFileSync } from 'node:fs';
import { addRuntime, addArrayRuntime } from '../../src/codegen-linear/runtime.js';
import { createEmptyModule } from '../../src/ir/types.js';
import { emitBinary } from '../../src/emit/binary.js';
const mod = createEmptyModule();
addRuntime(mod, {exposeArenaReset: true});addArrayRuntime(mod);
const bytes=emitBinary(mod);
if(!WebAssembly.validate(bytes))throw new Error('invalid production binary');
writeFileSync('.tmp/registry-current/runtime-artifacts.json',JSON.stringify({module:mod,binaryBase64:Buffer.from(bytes).toString('base64')},null,2)+'\n');
