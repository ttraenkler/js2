import hashlib,json,pathlib,subprocess,sys
root=pathlib.Path.cwd();out=root/'.tmp/neutral-layout'; label=sys.argv[1]
paths=[]
for folder in ['src','tests','scripts']:
 paths.extend(p for p in (root/folder).rglob('*') if p.is_file() and not p.is_symlink())
paths.extend(root/p for p in ['package.json','pnpm-lock.yaml','vitest.config.ts','tsconfig.json'])
rows={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
(out/f'{label}-inputs.json').write_text(json.dumps(rows,indent=2)+'\n')
(out/f'{label}-status.txt').write_bytes(subprocess.check_output(['git','status','--porcelain=v1']))
(out/f'{label}-head.txt').write_bytes(subprocess.check_output(['git','rev-parse','HEAD']))
if label=='after':
 assert rows==json.loads((out/'before-inputs.json').read_text());assert (out/'before-status.txt').read_bytes()==(out/'after-status.txt').read_bytes();assert (out/'before-head.txt').read_bytes()==(out/'after-head.txt').read_bytes()
print(label,len(rows))
