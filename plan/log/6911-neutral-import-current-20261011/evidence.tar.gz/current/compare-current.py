import sys,json,base64,subprocess
from pathlib import Path
from custody import *
EXPECTED=['input.json','before.json','after.json','receipt.json','errors.json','summary.json','observations.json','reporter.json','stdout.log','stderr.log','parent-terminal.json']
def freeze_delta(P,C):
 assert P['arm']=='P' and C['arm']=='C';assert P['cwd']==C['cwd']==str(ROOT);assert P['head']==C['head']==HEAD
 for key in P:
  if key not in ['arm','files']:assert P[key]==C[key],key
 p={r['path']:r for r in P['files']};c={r['path']:r for r in C['files']};assert p.keys()==c.keys();assert {name for name in p if p[name]!=c[name]}=={LEAF};assert p[LEAF]['mode']==c[LEAF]['mode']=='100644';assert p[LEAF]['committed']==c[LEAF]['committed'] is None
 assert regular(LEAF)==(HERE/'leaf-C.ts').read_bytes() or regular(LEAF)==(HERE/'leaf-P.ts').read_bytes()
 assert p[LEAF]['sha256']==sha((HERE/'leaf-P.ts').read_bytes());assert c[LEAF]['sha256']==sha((HERE/'leaf-C.ts').read_bytes());assert (HERE/'leaf-P.ts').read_text().replace('../../../ir/analysis/linear-memory-plan.js','../../../shared/contracts/linear-memory-layout.js')==(HERE/'leaf-C.ts').read_text()
def packet(arm):
 d=HERE/(arm+'-once');get=lambda n:json.loads((d/n).read_text());assert sorted(p.name for p in d.iterdir())==sorted(EXPECTED);before=get('before.json');after=get('after.json');assert before==after;freeze_bytes=(HERE/(arm+'-freeze.json')).read_bytes();assert before==json.loads(freeze_bytes)
 instrument={n:sha((HERE/n).read_bytes()) for n in INSTRUMENTS};expected_approval={'arm':arm,'head':HEAD,'freezeSha256':sha(freeze_bytes),'instrumentHashes':instrument,'release':'one-'+arm+'-pair'};assert json.loads((HERE/(arm+'-approval.json')).read_text())==expected_approval
 inp=get('input.json');assert inp=={'approved':before,'approval':expected_approval,'command':CMD,'childEnvironmentHashes':before['childEnvironmentHashes'],'instrumentHashes':instrument}
 errors=get('errors.json');receipt=get('receipt.json');result=receipt['result'];assert errors==receipt['errors']==[];assert receipt['childEnvironmentHashes']==inp['childEnvironmentHashes']==before['childEnvironmentHashes'];assert receipt['instrumentHashes']==instrument and receipt['freezeSha256']==sha(freeze_bytes);check_capture(result,errors)
 stdout=(d/'stdout.log').read_bytes();stderr=(d/'stderr.log').read_bytes();assert result['bytes']==result['capturedBytes']==len(stdout)+len(stderr)
 observed=get('observations.json');raw=base64.b64decode(observed['rawBase64']);assert observed['records']==[json.loads(line) for line in raw.decode().splitlines()];summary=validate(get('reporter.json'),stdout,stderr,raw);assert summary==get('summary.json')==receipt['summary'];check_report_exit(result,summary);prov=summary['provenance'];files={f['path']:f for f in before['files']};assert prov['head']==HEAD;assert prov['runtimeSha256']==files['src/codegen-linear/runtime.ts']['sha256'];assert prov['testSha256']==files[TESTS[0]]['sha256']=='a3e5d6fa5389615c2fe97faedb6f2f2228098ee6175ce53fb1cfc0a036b996b9'
 terminal=get('parent-terminal.json');assert terminal['independentParent'] is True and terminal['arm']==arm and terminal['naturalTerminal'] is True;assert terminal['exitCode']==result['code'] and terminal['signal'] is None;assert isinstance(terminal['execHandle'],str) and terminal['execHandle'];assert terminal['freezeSha256']==sha(freeze_bytes) and terminal['instrumentHashes']==instrument
 return summary,raw
def compare_sealed(manifest_path,root_approval_path):
 mbytes=Path(manifest_path).read_bytes();root_approval=json.loads(Path(root_approval_path).read_text());assert root_approval=={'manifestSha256':sha(mbytes),'release':'one-current-pair-comparison'};manifest=json.loads(mbytes);assert set(manifest)=={'P','C'}
 for arm in ['P','C']:
  assert sorted(e['path'] for e in manifest[arm])==sorted(EXPECTED)
  for e in manifest[arm]:data=(HERE/(arm+'-once')/e['path']).read_bytes();assert len(data)==e['bytes'] and sha(data)==e['sha256']
 freeze_delta(json.loads((HERE/'P-freeze.json').read_text()),json.loads((HERE/'C-freeze.json').read_text()));P,praw=packet('P');C,craw=packet('C');assert P==C,'whole ordered suites/status/failureMessages/provider/provenance/split-failures/full-stderr delta'
 for arm,raw in [('P',praw),('C',craw)]:
  path=HERE/('validated-'+arm+'-provider.jsonl');assert not path.exists();path.write_bytes(raw)
 proc=subprocess.run(['node','plan/log/6911-linear-char-code-at-20261007/compare-provider-rows.mjs',str(HERE/'validated-P-provider.jsonl'),str(HERE/'validated-C-provider.jsonl')],capture_output=True,text=True);assert proc.returncode==0,proc.stderr
 print(json.dumps({'casesPerArm':41,'passedPerArm':P['passed'],'failedPerArm':P['failed'],'skips':0,'orderedPerSuiteIdentitiesAndFullMessagesEqual':True,'completeSplitFailureTransportEqual':True,'fullStderrEqual':True,'wholeChildEnvironmentEqual':True,'onlyInputDelta':LEAF,'providerComparator':json.loads(proc.stdout)},indent=2))
if __name__=='__main__':compare_sealed(sys.argv[1],sys.argv[2])
