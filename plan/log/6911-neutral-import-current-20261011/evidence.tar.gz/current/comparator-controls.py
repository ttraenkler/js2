from pathlib import Path
import subprocess,json,gzip,hashlib,copy
out=Path('.tmp/6911-current/comparator-controls');out.mkdir(exist_ok=True);arch=Path('plan/log/6911-linear-char-code-at-20261007');base=arch/'baseline-v1.jsonl.gz';cand=arch/'candidate-v1.jsonl.gz';rows=[json.loads(line) for line in gzip.decompress(cand.read_bytes()).decode().splitlines()];mutations={}
mutations['missing-observation']=[r for r in rows if r.get('id')!='runtime-bmp']
dup=copy.deepcopy(rows);ob=[r for r in dup if r['kind']=='observation'];ob[1]['id']=ob[0]['id'];mutations['duplicate-id']=dup
bad=copy.deepcopy(rows)
def binaries(v,found):
 if isinstance(v,dict):
  if 'binaryBase64' in v:found.append(v)
  for val in v.values():binaries(val,found)
 elif isinstance(v,list):
  for val in v:binaries(val,found)
binrows=[];binaries(bad,binrows);assert len(binrows)==14;binrows[0]['sha256']='0'*64;mutations['wrong-binary-hash']=bad
missing=copy.deepcopy(rows);bw=[];binaries(missing,bw);del bw[0]['binaryBase64'];mutations['missing-binary-witness']=missing
changed=copy.deepcopy(rows);native=next(r for r in changed if r.get('id')=='native');native['evidence']['cases'][0]['auditUnexpectedValue']=1;mutations['full-record-delta']=changed
results={};cmd=['node',str(arch/'compare-provider-rows.mjs'),str(base),str(cand)];p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr;results['historical-positive']={'exit':p.returncode,'result':json.loads(p.stdout)}
for name,records in mutations.items():
 path=out/(name+'.jsonl');path.write_text('\n'.join(json.dumps(r,separators=(',',':')) for r in records)+'\n');p=subprocess.run(['node',str(arch/'compare-provider-rows.mjs'),str(base),str(path)],capture_output=True,text=True);assert p.returncode!=0,name;(out/(name+'.stderr')).write_text(p.stderr);results[name]={'exit':p.returncode,'rejected':True}
(out/'results.json').write_text(json.dumps({'status':'finite-validation-only','compilerExecuted':False,'originalArchivesUnchanged':True,'historicalInputs':{str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in [base,cand]},'controls':results},indent=2)+'\n');print(json.dumps({k:v['exit'] for k,v in results.items()}))
