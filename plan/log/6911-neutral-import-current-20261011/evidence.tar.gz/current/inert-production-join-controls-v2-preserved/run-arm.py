import os,sys,json,subprocess,selectors,time
from pathlib import Path
from custody import *
arm=sys.argv[1];approval_path=Path(sys.argv[2]);assert arm in ['P','C'];approval=json.loads(approval_path.read_text());freeze_path=HERE/(arm+'-freeze.json');freeze_bytes=freeze_path.read_bytes();instrument={n:sha((HERE/n).read_bytes()) for n in INSTRUMENTS};expected={'arm':arm,'head':HEAD,'freezeSha256':sha(freeze_bytes),'instrumentHashes':instrument,'release':'one-'+arm+'-pair'};assert approval==expected,'independent prelaunch approval mismatch';approved=json.loads(freeze_bytes);before=snapshot(arm);assert before==approved,'current inputs/environment differ from approved freeze';directory=HERE/(arm+'-once');directory.mkdir();assert not (ROOT/OBS).exists() and not (ROOT/REPORT).exists(),'stale observation/reporter'
jsonfile=lambda name,value:(directory/name).write_text(json.dumps(value,indent=2)+'\n');env=child_environment();jsonfile('input.json',{'approved':approved,'approval':approval,'command':CMD,'childEnvironmentHashes':env_hashes(env),'instrumentHashes':instrument});jsonfile('before.json',before);errors=[];process=None;state={'bytes':0,'capturedBytes':0,'droppedBytes':0,'closed':False,'code':None,'signal':None,'spawnError':None,'outputError':None,'timedOut':False,'truncated':False};streamfaults=set();handles={};started=time.time()
try:
 for name in ['stdout','stderr']:handles[name]=os.open(directory/(name+'.log'),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o644)
 process=subprocess.Popen(CMD,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env);selector=selectors.DefaultSelector()
 for name,pipe in [('stdout',process.stdout),('stderr',process.stderr)]:os.set_blocking(pipe.fileno(),False);selector.register(pipe,selectors.EVENT_READ,name)
 while selector.get_map():
  for key,mask in selector.select():
   chunk=os.read(key.fileobj.fileno(),65536);name=key.data
   if not chunk:selector.unregister(key.fileobj);key.fileobj.close();continue
   capture_chunk(state,name,chunk,handles[name],streamfaults,errors)
 code=process.wait();state.update(closed=True,code=code if code>=0 else None,signal=-code if code<0 else None)
except Exception as e:state['spawnError']=str(e);errors.append({'stage':'capture','error':str(e)})
finally:
 # Exception is not authorization to cancel the owned child: drain available streams and await natural closure.
 if process is not None and process.poll() is None:
  try:
   remainder=process.communicate()
   for name,data in zip(['stdout','stderr'],remainder):
    if data:state['bytes']+=len(data);state['droppedBytes']+=len(data)
  except Exception as e:errors.append({'stage':'drain','error':str(e)});process.wait()
  code=process.returncode;state.update(closed=True,code=code if code>=0 else None,signal=-code if code<0 else None)
 for fd in handles.values():
  try:os.close(fd)
  except Exception as e:errors.append({'stage':'close-stream','error':str(e)})
state['droppedBytes']=state['bytes']-state['capturedBytes'];summary=None
try:
 check_capture(state,errors)
 for source,target in [(REPORT,'reporter.json'),(OBS,'observations.json')]:
  data=(ROOT/source).read_bytes();(directory/target).write_bytes(data) if target=='reporter.json' else jsonfile(target,{'records':[json.loads(line) for line in data.decode().splitlines()],'rawBase64':__import__('base64').b64encode(data).decode()})
 report=json.loads((directory/'reporter.json').read_text());summary=validate(report,(directory/'stdout.log').read_bytes(),(directory/'stderr.log').read_bytes(),__import__('base64').b64decode(json.loads((directory/'observations.json').read_text())['rawBase64']));check_report_exit(state,summary);jsonfile('summary.json',summary)
except Exception as e:errors.append({'stage':'validate','error':str(e)})
try:
 after=snapshot(arm);jsonfile('after.json',after);assert after==before
except Exception as e:errors.append({'stage':'after-custody','error':str(e)})
jsonfile('errors.json',errors);jsonfile('receipt.json',{'arm':arm,'childEnvironmentHashes':env_hashes(env),'result':state,'summary':summary,'errors':errors,'startedEpoch':started,'finishedEpoch':time.time(),'instrumentHashes':instrument,'freezeSha256':sha(freeze_bytes)})
print(json.dumps({'arm':arm,'code':state['code'],'signal':state['signal'],'closed':state['closed'],'errors':len(errors)}));raise SystemExit(2 if errors else state['code'])
