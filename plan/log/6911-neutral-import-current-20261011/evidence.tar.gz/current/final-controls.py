from custody import *
import copy
from importlib.util import spec_from_file_location,module_from_spec
spec=spec_from_file_location('current_compare',HERE/'compare-current.py');module=module_from_spec(spec);spec.loader.exec_module(module)
arch=ROOT/'plan/log/6911-linear-char-code-at-20261007';report=json.loads(gzip.decompress((arch/'main-845/candidate41.json.gz').read_bytes()));log=gzip.decompress((arch/'main-845/candidate41.log.gz').read_bytes());provider=gzip.decompress((arch/'main-845/candidate-provider.jsonl.gz').read_bytes());passed=[]
def yes(name,fn):fn();passed.append(name)
def no(name,fn):
 try:fn()
 except (AssertionError,KeyError,ValueError):passed.append(name);return
 raise AssertionError('negative accepted '+name)
yes('archived complete41/ten provider positive',lambda:validate(report,log,b'',provider));original=validate(report,log,b'',provider);begin=log.index(b' FAIL ');footer=log.index(b' Test Files ',begin);out=log[:begin]+log[footer:];err=log[begin:footer];yes('failures carried in stderr positive',lambda:validate(report,out,err,provider));assert validate(report,out,err,provider)['failureText']['stderr']
for name,mut in [('missing case',lambda r:r['testResults'][0]['assertionResults'].pop()),('within-suite reordered case',lambda r:r['testResults'][0]['assertionResults'].reverse()),('suite identity',lambda r:r['testResults'][0].update(name='tests/wrong.test.ts')),('skipped case',lambda r:r['testResults'][0]['assertionResults'][0].update(status='pending')),('todo count',lambda r:r.update(numTodoTests=1))]:
 r=copy.deepcopy(report);mut(r);no(name,lambda:validate(r,log,b'',provider))
no('missing raw failure heading',lambda:validate(report,log.replace(b' FAIL ',b' OMIT ',1),b'',provider));no('duplicate failure footer',lambda:validate(report,log,b' Test Files ',provider));no('record transport duplicated across streams',lambda:validate(report,log,provider,provider));no('wrong observation population',lambda:validate(report,log,b'',b'\n'.join(provider.splitlines()[:-1])+b'\n'))
# Exact matched and mismatched summaries exercise full-message and complete split-transport comparison.
assert original==copy.deepcopy(original)
for name,mut in [('full failure message',lambda r:r['suites'][next(k for k,v in r['suites'].items() if any(t['status']=='failed' for t in v))][0].update(failureMessages=['altered'])),('complete stderr',lambda r:r.update(fullStderr='altered')),('stderr failure segment',lambda r:r['failureText'].update(stderr='altered'))]:
 changed=copy.deepcopy(original);mut(changed);no(name,lambda:__import__('operator').truth(original==changed) or (_ for _ in ()).throw(AssertionError(name)))
print(json.dumps({'controls':len(passed),'names':passed,'compilerChildExecuted':False}))
state={'bytes':0,'capturedBytes':0,'droppedBytes':0,'closed':True,'code':1,'signal':None,'spawnError':None,'outputError':None,'timedOut':False,'truncated':False};faults=set();errors=[];sink=[]
def write(fd,data):sink.append(data);return len(data)
capture_chunk(state,'stdout',b'abcdef',0,faults,errors,write);assert state['bytes']==state['capturedBytes']==6 and b''.join(sink)==b'abcdef';yes('healthy capture counter',lambda:check_capture(state,errors))
bad=copy.deepcopy(state);faults=set();errors=[];calls=[]
def partial_then_error(fd,data):
 calls.append(data)
 if len(calls)==1:return 2
 raise OSError('inert write fault')
capture_chunk(bad,'stderr',b'abcdef',0,faults,errors,partial_then_error);capture_chunk(bad,'stderr',b'excess',0,faults,errors,partial_then_error);bad['droppedBytes']=bad['bytes']-bad['capturedBytes'];assert bad['bytes']==18 and bad['capturedBytes']==8 and bad['droppedBytes']==10 and len(errors)==1 and len(calls)==2;no('partial capture fault rejects exact retained count',lambda:check_capture(bad,errors))
zero=copy.deepcopy(state);faults=set();errors=[];capture_chunk(zero,'stdout',b'ab',0,faults,errors,lambda fd,data:0);zero['droppedBytes']=zero['bytes']-zero['capturedBytes'];no('zero write rejects without busy loop',lambda:check_capture(zero,errors))
for name,key,value in [('signal','signal',15),('spawn fault','spawnError','inert'),('not naturally closed','closed',False),('timeout','timedOut',True),('truncation','truncated',True)]:
 x=copy.deepcopy(state);x[key]=value;no(name,lambda:check_capture(x,[]))
old=dict(os.environ)
try:
 os.environ['JS2WASM_UNKNOWN_AUDIT']='1';no('unknown child configuration fails closed',child_environment)
finally:os.environ.clear();os.environ.update(old)
print(json.dumps({'finalControls':len(passed),'compilerChildExecuted':False,'names':passed}))
# INERT synthetic join fixtures: historical data exercises actual production joins;
# these are not current compiler runs, approvals, or parent terminal evidence.
import base64,contextlib,io,shutil
fixture=HERE/'inert-production-join-controls';assert not fixture.exists();fixture.mkdir()
real_here=module.HERE
for n in INSTRUMENTS+['leaf-P.ts','leaf-C.ts']:shutil.copyfile(HERE/n,fixture/n)
rows=[json.loads(s) for s in provider.decode().splitlines()];prov=next(r for r in rows if r['kind']=='provenance');oldprov=next(s for s in provider.decode().splitlines() if json.loads(s)['kind']=='provenance');prov['head']=HEAD;newprov=json.dumps(prov,separators=(',',':'));fixture_raw=provider.replace(oldprov.encode(),newprov.encode());fixture_stdout=log.replace(oldprov.encode(),newprov.encode());fixture_summary=validate(report,fixture_stdout,b'',fixture_raw)
instrument={n:sha((fixture/n).read_bytes()) for n in INSTRUMENTS}
put=lambda path,value:path.write_text(json.dumps(value,indent=2)+'\n')
module.HERE=fixture
try:
 for arm in ['P','C']:
  d=fixture/(arm+'-once');d.mkdir();leaf=(fixture/('leaf-'+arm+'.ts')).read_bytes()
  before={'arm':arm,'cwd':str(ROOT),'head':HEAD,'childEnvironmentHashes':{'INERT_FIXTURE':sha(b'not execution')},'command':CMD,'files':[{'path':LEAF,'mode':'100644','committed':None,'sha256':sha(leaf)},{'path':'src/codegen-linear/runtime.ts','sha256':prov['runtimeSha256']},{'path':TESTS[0],'sha256':prov['testSha256']}]}
  put(fixture/(arm+'-freeze.json'),before);freeze_sha=sha((fixture/(arm+'-freeze.json')).read_bytes());approval={'arm':arm,'head':HEAD,'freezeSha256':freeze_sha,'instrumentHashes':instrument,'release':'one-'+arm+'-pair'};put(fixture/(arm+'-approval.json'),approval)
  state={'bytes':len(fixture_stdout),'capturedBytes':len(fixture_stdout),'droppedBytes':0,'closed':True,'code':1,'signal':None,'spawnError':None,'outputError':None,'timedOut':False,'truncated':False}
  for name,obj in {'input.json':{'approved':before,'approval':approval,'command':CMD,'childEnvironmentHashes':before['childEnvironmentHashes'],'instrumentHashes':instrument},'before.json':before,'after.json':before,'receipt.json':{'childEnvironmentHashes':before['childEnvironmentHashes'],'instrumentHashes':instrument,'freezeSha256':freeze_sha,'result':state,'errors':[],'summary':fixture_summary},'errors.json':[],'summary.json':fixture_summary,'observations.json':{'records':rows,'rawBase64':base64.b64encode(fixture_raw).decode()},'reporter.json':report,'parent-terminal.json':{'independentParent':True,'arm':arm,'naturalTerminal':True,'exitCode':1,'signal':None,'execHandle':'INERT-FIXTURE-NOT-A-REAL-HANDLE','freezeSha256':freeze_sha,'instrumentHashes':instrument}}.items():put(d/name,obj)
  (d/'stdout.log').write_bytes(fixture_stdout);(d/'stderr.log').write_bytes(b'')
 def seal():
  manifest={arm:[{'path':n,'bytes':len((fixture/(arm+'-once')/n).read_bytes()),'sha256':sha((fixture/(arm+'-once')/n).read_bytes())} for n in module.EXPECTED] for arm in ['P','C']};put(fixture/'manifest.json',manifest);put(fixture/'manifest-approval.json',{'manifestSha256':sha((fixture/'manifest.json').read_bytes()),'release':'one-current-pair-comparison'})
 seal()
 yes('production packet positive synthetic fixture',lambda:module.packet('P'))
 yes('production soleleaf freeze delta positive',lambda:module.freeze_delta(json.loads((fixture/'P-freeze.json').read_text()),json.loads((fixture/'C-freeze.json').read_text())))
 with contextlib.redirect_stdout(io.StringIO()) as captured:
  yes('production sealed22/full provider comparator positive synthetic fixture',lambda:module.compare_sealed(fixture/'manifest.json',fixture/'manifest-approval.json'))
 (fixture/'positive-comparison.txt').write_text('INERT synthetic control, not current execution\n'+captured.getvalue())
 for name in ['validated-P-provider.jsonl','validated-C-provider.jsonl']:(fixture/name).unlink()
 def mutated_file(name,path,mut,invoke):
  original_bytes=path.read_bytes();value=json.loads(original_bytes);mut(value);put(path,value)
  try:no(name,invoke)
  finally:path.write_bytes(original_bytes)
 invoke=lambda:module.packet('P');d=fixture/'P-once'
 for name,key,val in [('command','command',['node','inert-wrong-command']),('environment','childEnvironmentHashes',{'WRONG':sha(b'wrong')})]:mutated_file('production input '+name+' mismatch',d/'input.json',lambda obj,k=key,v=val:obj.update({k:v}),invoke)
 mutated_file('production parent terminal mismatch',d/'parent-terminal.json',lambda x:x.update(exitCode=0),invoke)
 mutated_file('production recomputed summary mismatch',d/'summary.json',lambda x:x.update(passed=41),invoke)
 mutated_file('production observation/raw mismatch',d/'observations.json',lambda x:x['records'].pop(),invoke)
 mutated_file('production reporter/child exit mismatch',d/'receipt.json',lambda x:x['result'].update(code=0),invoke)
 missing=d/'stderr.log';saved=missing.read_bytes();missing.unlink()
 try:no('production packet missing member',invoke)
 finally:missing.write_bytes(saved)
 sealed=lambda:module.compare_sealed(fixture/'manifest.json',fixture/'manifest-approval.json')
 mutated_file('production sealed manifest missing member',fixture/'manifest.json',lambda x:x['P'].pop(),sealed)
 # Reapprove deliberately incomplete fixture manifest to reach the production member check.
 oldmanifest=(fixture/'manifest.json').read_bytes();oldapproval=(fixture/'manifest-approval.json').read_bytes();obj=json.loads(oldmanifest);obj['P'].pop();put(fixture/'manifest.json',obj);put(fixture/'manifest-approval.json',{'manifestSha256':sha((fixture/'manifest.json').read_bytes()),'release':'one-current-pair-comparison'})
 try:no('production reapproved incomplete manifest rejected',sealed)
 finally:(fixture/'manifest.json').write_bytes(oldmanifest);(fixture/'manifest-approval.json').write_bytes(oldapproval)
 badfreeze=json.loads((fixture/'C-freeze.json').read_text());badfreeze['files'][0]['sha256']=sha(b'wrong leaf');no('production wrong soleleaf freeze hash',lambda:module.freeze_delta(json.loads((fixture/'P-freeze.json').read_text()),badfreeze))
 badfreeze=json.loads((fixture/'C-freeze.json').read_text());badfreeze['files'][1]['sha256']=sha(b'foreign source');no('production extra source freeze delta',lambda:module.freeze_delta(json.loads((fixture/'P-freeze.json').read_text()),badfreeze))
 yes('exit0 iff failed0 positive',lambda:check_report_exit({'code':0},{'failed':0}));no('exit1 with failed0 rejected',lambda:check_report_exit({'code':1},{'failed':0}))
finally:module.HERE=real_here
print(json.dumps({'finalControls':len(passed),'compilerChildExecuted':False,'fixtureKind':'explicitly inert synthetic production-join fixtures','names':passed}))
