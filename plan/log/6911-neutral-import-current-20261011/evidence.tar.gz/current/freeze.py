from pathlib import Path
import sys,json
from custody import HERE,snapshot
arm=sys.argv[1];path=Path(sys.argv[2]);assert not path.exists(),'immutable freeze output exists';path.write_text(json.dumps(snapshot(arm),indent=2)+'\n')
