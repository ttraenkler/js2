from pathlib import Path
import subprocess,json,os,hashlib,time
root=Path.cwd();out=Path('.tmp/6911-current');child_env=dict(os.environ,JS2WASM_LINEAR_IR='1',JS2WASM_CHAR_CODE_AT_OBSERVATIONS='.tmp/6911-current/provider.jsonl');cmd=['node','node_modules/vitest/dist/cli.js','run','tests/issue-6911-linear-ir-char-code-at-provider-body.test.ts','tests/issue-2956.test.ts','tests/linear-charcodeat-ascii-fast-path.test.ts','--pool=forks','--poolOptions.forks.singleFork=true','--no-file-parallelism','--reporter=default','--reporter=json','--outputFile=.tmp/6911-current/report.json']
for name in ['stdout.log','stderr.log','report.json','provider.jsonl','epoch-before.json','epoch-after-full.json','terminal.json']:assert not (out/name).exists(),'stale output '+name
subprocess.run(['python3',str(out/'freeze.py')],check=True,env=child_env);before=json.loads((out/'epoch-before.json').read_text());started=time.time();process=None
try:
 with (out/'stdout.log').open('xb') as stdout,(out/'stderr.log').open('xb') as stderr:
  process=subprocess.Popen(cmd,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,env=child_env);code=process.wait()
finally:
 # Never cancel a live compiler child, including exceptional parent paths.
 if process is not None and process.poll() is None:process.wait()
terminal={'command':cmd,'cwd':str(root),'head':before['head'],'returncode':process.returncode if process else None,'naturalTerminal':process is not None and process.poll() is not None,'startedEpoch':started,'finishedEpoch':time.time(),'externalDeadline':None,'nodeOptions':child_env.get('NODE_OPTIONS',''),'childEnvironmentHashes':{k:hashlib.sha256(v.encode()).hexdigest() for k,v in sorted(child_env.items())},'streams':{name:{'bytes':(out/name).stat().st_size,'sha256':hashlib.sha256((out/name).read_bytes()).hexdigest()} for name in ['stdout.log','stderr.log']}}
subprocess.run(['python3',str(out/'freeze.py')],check=True,env=dict(child_env,JS2WASM_EPOCH_OUTPUT=str(out/'epoch-after-full.json')));after=json.loads((out/'epoch-after-full.json').read_text());after['childEnvironmentHashes'].pop('JS2WASM_EPOCH_OUTPUT',None);assert after==before,'execution inputs/population changed';terminal['fullInputCustodyUnchanged']=True;(out/'terminal.json').write_text(json.dumps(terminal,indent=2)+'\n');print(json.dumps({'returncode':terminal['returncode'],'naturalTerminal':terminal['naturalTerminal'],'custodyUnchanged':True}));raise SystemExit(terminal['returncode'])
