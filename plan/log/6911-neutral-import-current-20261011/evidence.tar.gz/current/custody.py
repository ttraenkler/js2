from pathlib import Path
import os,stat,subprocess,hashlib,json,re,gzip
ROOT=Path('/Volumes/Archiv Mini/Users/thomas/Code/ts2wasm/.claude/worktrees/codex-6911-neutral-import-current-20261011-01a12827')
HERE=ROOT/'.tmp/6911-current';HEAD='e5605c8c0fb6b42ce29fe8aad7165cf168108c1c';LEAF='src/codegen-linear/runtime/strings/char-code-at.ts';OBS='.tmp/6911-current/active-provider.jsonl';REPORT='.tmp/6911-current/active-reporter.json'
TESTS=['tests/issue-6911-linear-ir-char-code-at-provider-body.test.ts','tests/issue-2956.test.ts','tests/linear-charcodeat-ascii-fast-path.test.ts']
CMD=['node','node_modules/vitest/dist/cli.js','run',*TESTS,'--pool=forks','--poolOptions.forks.singleFork=true','--no-file-parallelism','--reporter=default','--reporter=json','--outputFile='+REPORT]
INSTRUMENTS=['custody.py','freeze.py','run-arm.py','compare-current.py']
sha=lambda b:hashlib.sha256(b).hexdigest()
def regular(name):
 p=ROOT
 for part in Path(name).parts:
  assert part not in ['..',''];p=p/part;assert not p.is_symlink(),name
 assert p.is_file(),name
 return p.read_bytes()
def child_environment():
 env=dict(os.environ)
 assert 'NODE_OPTIONS' not in env,'NODE_OPTIONS must be absent'
 allowed={'JS2WASM_LINEAR_IR':['1'],'JS2WASM_CHAR_CODE_AT_OBSERVATIONS':[OBS],'CI':['true','false','1','0'],'NO_COLOR':['1'],'FORCE_COLOR':['0','1','2','3'],'TERM':['dumb','xterm','xterm-256color'],'NODE_ENV':['test','development','production'],'TZ':['UTC','Europe/Berlin'],'LANG':['C','C.UTF-8','en_US.UTF-8','en_GB.UTF-8','de_DE.UTF-8'],'LC_ALL':['C','C.UTF-8','en_US.UTF-8'],'LC_CTYPE':['C','UTF-8','C.UTF-8','en_US.UTF-8']}
 for key,value in env.items():
  if key in allowed:assert value in allowed[key],key
  elif re.match(r'^(NODE|JS2WASM|VITE|TEST262|COMPILER|PNPM|COREPACK|NPM_CONFIG|LC_|ESBUILD|TSX|TS_NODE|BABEL|SWC)',key,re.I):raise AssertionError('unknown influencing environment '+key)
 env.update(JS2WASM_LINEAR_IR='1',JS2WASM_CHAR_CODE_AT_OBSERVATIONS=OBS)
 return env
def env_hashes(env):return {k:sha(v.encode()) for k,v in sorted(env.items())}
def snapshot(arm):
 assert Path.cwd()==ROOT;assert arm in ['P','C'];paths=set();tracked={}
 selected=lambda p:p=='biome.json' or p.startswith(('src/','tests/','scripts/')) or bool(re.search(r'(^|/)(package.json|pnpm-lock.yaml|pnpm-workspace.yaml|(?:ts|js)config[^/]*\.json|(?:vite|vitest)[^/]*config[^/]*|vitest.workspace[^/]*|\.npmrc|\.nvmrc|\.node-version)$',p))
 for raw in subprocess.check_output(['git','ls-files','--stage','-z']).decode().split('\0'):
  if not raw:continue
  meta,name=raw.split('\t');mode,blob,stage=meta.split();assert stage=='0'
  if selected(name):paths.add(name);tracked[name]={'mode':mode,'committedBlob':blob}
 for group in ['src','tests','scripts']:
  for directory,dirs,files in os.walk(ROOT/group,followlinks=False):
   for d in dirs:assert not (Path(directory)/d).is_symlink()
   for f in files:paths.add(str((Path(directory)/f).relative_to(ROOT)))
 for p in ROOT.iterdir():
  if p.is_file() and selected(p.name):paths.add(p.name)
 paths.update('.tmp/6911-current/'+n for n in INSTRUMENTS+['final-controls.py','comparator-controls.py','environment-omission.json','instrument-plan.md']);paths.add('.tmp/6911-current/tsconfig.test-inclusive.json');paths.add('.tmp/6911-current/ordered-case-identities.json');paths.add('plan/log/6911-linear-char-code-at-20261007/compare-provider-rows.mjs');paths.add('plan/log/6911-linear-char-code-at-20261007/main-845/candidate41.json.gz')
 mandatory=[*TESTS,LEAF,'src/codegen-linear/runtime.ts','src/shared/contracts/linear-memory-layout.ts','src/ir/analysis/linear-memory-plan.ts','src/ir/analysis/allocation-evidence/metadata.ts','scripts/compiler-boundaries.json','package.json','pnpm-lock.yaml','tsconfig.ts7.json','vitest.config.ts','biome.json']
 for name in mandatory:assert name in paths and (ROOT/name).is_file(),name
 files=[]
 for name in sorted(paths):
  data=regular(name);mode='100755' if (ROOT/name).stat().st_mode&0o111 else '100644';assert name not in tracked or mode==tracked[name]['mode'];files.append({'path':name,'bytes':len(data),'sha256':sha(data),'mode':mode,'physicalBlob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(),'committed':tracked.get(name)})
 deps={}
 for name in ['node_modules/vitest/package.json','node_modules/vitest/dist/cli.js','node_modules/typescript7/package.json','node_modules/typescript7/lib/tsc.js','node_modules/vite/package.json','node_modules/binaryen/package.json','node_modules/@biomejs/biome/package.json']:
  p=ROOT/name;assert p.is_file(),name;data=p.read_bytes();deps[name]={'resolved':str(p.resolve()),'bytes':len(data),'sha256':sha(data)}
 tool=json.loads(subprocess.check_output(['node','-p','JSON.stringify({node:process.version,v8:process.versions.v8,execPath:process.execPath,platform:process.platform,arch:process.arch})']));assert tool['node']=='v25.9.0';tool['nodeBinarySha256']=sha(Path(tool['execPath']).read_bytes())
 head=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip();assert head==HEAD
 env=child_environment();return {'arm':arm,'cwd':str(ROOT),'head':head,'sourceTree':subprocess.check_output(['git','rev-parse','HEAD:src']).decode().strip(),'dirty':subprocess.check_output(['git','status','--short']).decode(),'files':files,'selectedDependencies':deps,'toolchain':tool,'childEnvironmentHashes':env_hashes(env),'command':CMD,'externalDeadline':None}
def ordered_schema():return json.loads((HERE/'ordered-case-identities.json').read_text())
def failure_transport(stdout,stderr,failed):
 if not failed:
  assert stdout.count(' FAIL ')+stderr.count(' FAIL ')==0;return {'stdout':'','stderr':''}
 assert stdout.count(' FAIL ')+stderr.count(' FAIL ')==failed,'failure heading population';assert stdout.count(' Test Files ')+stderr.count(' Test Files ')==1,'failure footer population'
 def segment(text):
  begin=text.find(' FAIL ')
  if begin<0:return ''
  end=text.find(' Test Files ',begin);return text[begin:end if end>=0 else len(text)]
 return {'stdout':segment(stdout),'stderr':segment(stderr)}
def validate(report,stdout_bytes,stderr_bytes,provider_bytes):
 stdout=stdout_bytes.decode();stderr=stderr_bytes.decode();assert stdout.encode()==stdout_bytes and stderr.encode()==stderr_bytes
 assert not re.search(r'Unhandled Error|unhandledRejection|Uncaught Exception|FATAL ERROR|ERR_IPC_CHANNEL_CLOSED',stdout+stderr)
 assert report['numTotalTests']==41 and report['numPassedTests']+report['numFailedTests']==41;assert report['numPendingTests']==report['numTodoTests']==0;assert len(report['testResults'])==3
 schema=ordered_schema();suites={}
 for file in report['testResults']:
  name=Path(file['name']).name;assert name in schema and name not in suites;tests=file['assertionResults'];assert [t['fullName'] for t in tests]==schema[name];assert all(t['status'] in ['passed','failed'] for t in tests)
  if name==Path(TESTS[0]).name:assert len(tests)==10 and all(t['status']=='passed' for t in tests)
  for t in tests:assert (t['status']=='passed' and t['failureMessages']==[]) or (t['status']=='failed' and len(t['failureMessages'])>0)
  assert file['status']==('failed' if any(t['status']=='failed' for t in tests) else 'passed')
  suites[name]=[{'name':t['fullName'],'status':t['status'],'failureMessages':t['failureMessages']} for t in tests]
 assert set(suites)==set(schema)
 assert sum(t['status']=='passed' for tests in suites.values() for t in tests)==report['numPassedTests'];assert sum(t['status']=='failed' for tests in suites.values() for t in tests)==report['numFailedTests']
 rows=[json.loads(s) for s in provider_bytes.decode().splitlines()];assert len(rows)==12;obs=[r for r in rows if r['kind']=='observation'];assert len(obs)==10 and all(r['status']=='passed' and r['failure'] is None for r in obs);assert len([r for r in rows if r['kind']=='provenance'])==1 and len([r for r in rows if r['kind']=='population'])==1
 transport=[]
 for stream,text in [('stdout',stdout),('stderr',stderr)]:
  captured=[json.loads(s) for s in text.splitlines() if s.startswith('{"issue":6911,')]
  if captured:transport.append((stream,captured))
 assert len(transport)==1 and transport[0][1]==rows,'console/JSONL transport mismatch'
 return {'cases':41,'passed':report['numPassedTests'],'failed':report['numFailedTests'],'pending':0,'suites':suites,'failureText':failure_transport(stdout,stderr,report['numFailedTests']),'fullStderr':stderr,'providerStream':transport[0][0],'provenance':next(r for r in rows if r['kind']=='provenance'),'observations':obs}
def capture_chunk(state,name,chunk,fd,faults,errors,write=os.write):
 state['bytes']+=len(chunk)
 if name in faults:return
 written=0
 try:
  while written<len(chunk):
   n=write(fd,chunk[written:]);assert n>0,'zero-byte capture write';written+=n;state['capturedBytes']+=n
 except Exception as error:faults.add(name);state['outputError']=str(error);errors.append({'stage':'stream-write','stream':name,'error':str(error)})
def check_capture(state,errors):
 assert errors==[];assert state['closed'] and state['signal'] is None and state['spawnError'] is None and state['outputError'] is None and state['timedOut']==state['truncated']==False and state['droppedBytes']==0;assert state['code'] in [0,1]

def check_report_exit(state,summary):
 assert state["code"]==(0 if summary["failed"]==0 else 1),"child exit/reporter mismatch"
