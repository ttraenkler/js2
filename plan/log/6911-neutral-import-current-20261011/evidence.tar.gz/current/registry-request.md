Proposed exact matching-path current composition request for issue6911, Linear IR charCodeAt provider: reusable emission body and exact preservation.

Only these three already-published entries from PR6583 head ed60d9648c1f726bf843656ffd12ce6710d539c6:

1. files: src/codegen-linear/runtime/strings/char-code-at.ts; state unmigrated; layer legacy-linear.
2. nonModules: src/codegen-linear/runtime/README.md; reason "Linear runtime body documentation; not implementation or type code."
3. nonModules: src/codegen-linear/runtime/strings/README.md; reason "Linear string runtime body documentation; not implementation or type code."

The root runtime README is exactly the same12-line published initializer README; coordinate one insertion with active6905 rather than duplicate its entry. Keep all current source classifications, retained policy bytes/order, layers/allowedEdges/evidence/roots/exclusions/helpers untouched. No wildcard, gate change, migration debt erasure or native admission is requested. Historical6911 registry-handoff record remains done; current rows are not applied without matching A authority.

This is a local draft only. No comment, claim mutation for registry, HOLD or queue request has been sent.
