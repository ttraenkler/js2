from pathlib import Path
import os,json,hashlib,tarfile,gzip,io,subprocess,shutil
root=Path.cwd();scratch=root/'.tmp/6911-final-seal';payload=scratch/'payload';payload.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest()
def copy(source,target):
 assert source.is_file() and not source.is_symlink(),str(source);dst=payload/target;assert not dst.exists();dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(source.read_bytes())
for directory,label in [('.tmp/6911-current','current'),('.tmp/6911-readonly-P','read-only-P'),('.tmp/6911-readonly-C','read-only-C'),('.tmp/6911-C-qualification','C1-qualification'),('.tmp/6911-format-C2-proof','C2-format-proof'),('.tmp/6911-C2-qualification','C2-qualification')]:
 for p in sorted((root/directory).rglob('*')):
  if '__pycache__' in p.parts:continue
  if p.is_file():copy(p,Path(label)/p.relative_to(root/directory))
historical='plan/log/6911-linear-char-code-at-20261007';donor='ed60d9648c1f726bf843656ffd12ce6710d539c6';names=subprocess.check_output(['git','ls-tree','-r','--name-only',donor,'--',historical]).decode().splitlines();assert len(names)==39
for name in names:
 data=(root/name).read_bytes();assert data==subprocess.check_output(['git','show',donor+':'+name]);copy(root/name,Path('historical')/Path(name).relative_to(historical))
sourcepaths=['src/codegen-linear/runtime.ts','src/codegen-linear/runtime/strings/char-code-at.ts','src/codegen-linear/runtime/README.md','src/codegen-linear/runtime/strings/README.md','tests/issue-6911-linear-ir-char-code-at-provider-body.test.ts','tests/issue-2956.test.ts','tests/linear-charcodeat-ascii-fast-path.test.ts','scripts/compiler-boundaries.json','src/shared/contracts/linear-memory-layout.ts','src/ir/analysis/linear-memory-plan.ts','src/ir/analysis/allocation-evidence/metadata.ts']
for name in sourcepaths:copy(root/name,Path('final-source')/name)
originalissue=subprocess.check_output(['git','show',donor+':plan/issues/6911-linear-ir-char-code-at-provider-body.md']);(payload/'historical/issue6911-published.md').write_bytes(originalissue)
summary={'base':'e5605c8c0fb6b42ce29fe8aad7165cf168108c1c','publishedDonor':donor,'PactualRootHandle':'28596','C1actualRootHandle':'38118','firstWorkerFreezeRefusalHandle':'40644','refusalSpawnedCompiler':False,'C1buildHandle':'11753','C1buildExit':0,'runtimeCasesEach':41,'passedEach':38,'failedEach':3,'skipsTodos':0,'providerObservations':10,'wholeBinaryWitnesses':14,'threeNativeFailuresRemainOpen':True,'canonicalInventoryExit':1,'canonicalInventoryUnclassifiedErrors':4,'registryRowsAdopted':False,'C1formatExit':1,'C2formatExit':0,'C1source':'758bee05f24052034069c659a492c867672b664a35318c75713e96401fb2039b','C2finalSource':'584d8223a2fa2f5c5d0b52e7a7d4484daa5a606de26c6833893a25302b1cbb59','C2RuntimeOrBuildExecuted':False,'C2Join':'Exact outside-import bytes, semantic AST and canonical esbuild JS equality; normal formatting/LOC/cycle and full graph equality; final7938 census sole leaf formatting delta. Default TS/esbuild pretty bytes differ, preserved truthfully.','Ptyping':'not measured in current epoch; no pairedtyping claim','C1sourceAndOwnedTestInclusiveTypingExit':0,'historicalArchiveOriginalFiles':39,'historicalArchiveOriginalBytes':754995,'nativeAdmissionGate1RetirementCredit':False,'fullDependencyPopulationProof':False,'selectedDependencyProof':'Seven selected dependency files plus installed Node hash; exact resolved path/byte custody only.','policyMetadata':'Exact canonical e560; unchanged; three-entry registry request remains local and ungranted.','publication':'No commit/push/public comment/PRhead/HOLD/queue change authorized by this seal.'};(payload/'qualification-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
copy(Path(__file__),Path('sealing-instrument/seal.py'))
files=sorted(p for p in payload.rglob('*') if p.is_file());manifest=[{'path':str(p.relative_to(payload)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files];(payload/'inner-hashes.json').write_text(json.dumps(manifest,indent=2)+'\n');stream=io.BytesIO()
with tarfile.open(fileobj=stream,mode='w',format=tarfile.GNU_FORMAT) as tar:
 for p in sorted(x for x in payload.rglob('*') if x.is_file()):
  data=p.read_bytes();info=tarfile.TarInfo(str(p.relative_to(payload)));info.size=len(data);info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';tar.addfile(info,io.BytesIO(data))
archive=scratch/'evidence.tar.gz';archive.write_bytes(gzip.compress(stream.getvalue(),compresslevel=9,mtime=0));extracted=scratch/'extracted';extracted.mkdir()
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members);tar.extractall(extracted,filter='data')
expected={r['path'] for r in manifest}|{'inner-hashes.json'};assert {str(p.relative_to(extracted)) for p in extracted.rglob('*') if p.is_file()}==expected
for r in manifest:data=(extracted/r['path']).read_bytes();assert len(data)==r['bytes'] and sha(data)==r['sha256'];assert data==(payload/r['path']).read_bytes()
for name in names:assert (extracted/'historical'/Path(name).relative_to(historical)).read_bytes()==subprocess.check_output(['git','show',donor+':'+name])
old=extracted/'current/rejected-worker-environment-epoch';oldhashes=json.loads((old/'preserved-hashes.json').read_text());assert len(oldhashes)==49
for r in oldhashes:data=(old/r['path']).read_bytes();assert len(data)==r['bytes'] and sha(data)==r['sha256']
receipt={'archiveBytes':archive.stat().st_size,'archiveSha256':sha(archive.read_bytes()),'hashedInnerFiles':len(manifest),'archiveRegularMembers':len(expected),'allHashesVerified':True,'exactHistorical39AndRejectedWorker49Verified':True,'symlinksOrUnlistedMembers':False};(scratch/'seal-verification.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
