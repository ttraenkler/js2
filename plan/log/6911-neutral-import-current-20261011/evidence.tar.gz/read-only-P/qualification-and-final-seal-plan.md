Private qualification/seal plan. Nothing here launches a compiler, test, typechecker, build, hook, or publication.

Execution custody
- Root owns the actual P and conditional C handles, standalone identical browser-key-omission/Node25 prefix and all35 full child environment hashes. No selected input edits while either arm is live.
- Original worker45 prerequisite manifest and its artifacts, approval, actual40644 preflight refusal and root diagnostic are preserved in the49-original rejected-worker-environment-epoch. Its preserved-hashes.json binds every copy. Keep the actual refusal distinct from compiler execution.
- Current root52 prerequisite manifest pins all approved instruments/freezes plus explicit old-epoch references. Preserve root P/C approval bytes and actual parent capture logs/terminal handles. Each actual arm must have exactly11 files specified by frozen compare-current.py. Seal the resulting22 paths and obtain root's separate exact manifest approval before frozen comparison; never fabricate a terminal or current observation.
- Preserve complete41 ordered per-suite case identities and actual statuses/messages. Current totals are observed, not historical38/3 assumptions. Preserve exact ten provider observations and14 whole binary witnesses with original full comparator. Keep failures as failures, no skips/todos or diagnostics truncation.

C qualification AFTER valid natural P/C terminals and reviewed comparison, serialized with other heavy lanes
Every command uses installed /Users/thomas/.nvm/versions/node/v25.9.0/bin at PATH front, fixed physical worktree, default heap and no NODE_OPTIONS. Capture each command argv, full stdout/stderr bytes+SHA, actual natural exit and source/input receipt separately under NEW .tmp/6911-C-qualification; no overwrite of pair artifacts. Root must authorize timing. No test/source/config edits to repair gate failures implicitly.

Strict source:
node node_modules/typescript7/lib/tsc.js --noEmit -p tsconfig.ts7.json
Strict complete source plus owned original test (frozen config, incremental false):
node node_modules/typescript7/lib/tsc.js --noEmit -p .tmp/6911-current/tsconfig.test-inclusive.json
Read-only lint:
node_modules/.bin/biome lint src/codegen-linear/runtime.ts src/codegen-linear/runtime/strings/char-code-at.ts tests/issue-6911-linear-ir-char-code-at-provider-body.test.ts --diagnostic-level=error --max-diagnostics=none
Read-only format:
node_modules/.bin/prettier --check src/codegen-linear/runtime.ts src/codegen-linear/runtime/strings/char-code-at.ts tests/issue-6911-linear-ir-char-code-at-provider-body.test.ts
Current exacte560 budgets/ratchets, without grant/baseline changes:
LOC_GATE_BASE=e5605c8c0fb6b42ce29fe8aad7165cf168108c1c node scripts/check-loc-budget.mjs
LOC_GATE_BASE=e5605c8c0fb6b42ce29fe8aad7165cf168108c1c node scripts/check-flat-dir-budget.mjs
LOC_GATE_BASE=e5605c8c0fb6b42ce29fe8aad7165cf168108c1c node scripts/check-coercion-sites.mjs
LOC_GATE_BASE=e5605c8c0fb6b42ce29fe8aad7165cf168108c1c node scripts/check-oracle-ratchet.mjs
node scripts/check-ir-dialect.mjs
node scripts/audit-legacy-reachability.mjs --check --moved-reference-contract=preservation-v1 --require-core-types --require-core-nodes
LOC_GATE_BASE=e5605c8c0fb6b42ce29fe8aad7165cf168108c1c node scripts/check-import-cycles.mjs --json
Canonical inventory, no proposed registry rows adopted:
node scripts/check-compiler-boundaries.mjs --mode inventory --base e5605c8c0fb6b42ce29fe8aad7165cf168108c1c
Expect exactly4 errors while three policy entries remain ungranted: runtimeREADME and stringsREADME unclassified-nonmodule; char-code-at leaf unclassified-module and unclassified-target. Record exit1 truthfully, no whole inventory green credit. Exact A policy and metadata remain canonical.
Full normal build, only after pair terminal and heavy-lane serialization:
npm run build
This expands unchanged Vite/prune declarations/build-test262 CLI sequence; default Node25 heap/no deadline override/no cancellation. Keep historical failures unresolved unless actual current normal run passes. Capture natural terminal and generated-output observations; don't stage generated output or infer full native migration/retirement credit.

Full graph preservation
P graph already captured using exported production buildGraph, all references/nodes/adjacency,1,907nodes/10,561valueedges/3,881type-only skipped; Pcycle gate1 exactcodegen-linear→IR9→10. C full graph and gate receipts come only after C install+terminal. Require identical full node set/reference population apart from soleleaf's one specifier; adjacency delta removes char-code-at→ir/analysis/linear-memory-plan.ts and adds char-code-at→shared/contracts/linear-memory-layout.ts. All other adjacency and current SCC/directory-edge metrics must be verified, not guessed. Keep full canonical inventory population/edges/JSON/errors for both arms.

Historical donor preservation
Actual donor ed60d9648c1f726bf843656ffd12ce6710d539c6 publishes39 files under plan/log/6911-linear-char-code-at-20261007, totaling754,995bytes; ALL39 current copies byte-equal donor git blobs. donor-preservation.json independently records each path/count/SHA/blob and four additional unchanged published inputs (stringsREADME and all three original cohort tests). Do not claim35 files. Runtime current composition and leaf import-only difference use approved inverse/composition proof rather than whole donor-runtime equality. Source rootREADME remains exact initializer12line body.

Finite final archive coverage
Payload explicitly includes: all39 historical donor files byteexact; all49 rejected-worker originals+preserved hashmanifest; both old45/currentroot52 prerequisite manifests; actual root approvals/freezes/diagnostics/epoch note; unchanged four instruments,39-control code/logs/labelled inert fixtures plus original full binary controls; rawledger/grant authority; both actual11-member arm packets and external parent capture logs; paired22 manifest/root comparison approval/natural comparator output; P/C full graphs and canonical inventory JSON/raw diagnostics/exits; composition/soleimport/body inverse proof; exact donor-preservation receipt; all strict/lint/format/ratchet/dead-export/dialect/build natural receipts. Seal truthfully even if a gate fails; don't relabel historical/custody failures successful.
Create sorted manifest over EVERY payload regular file, bytes+SHA256, refuse unlisted members/symlinks. Deterministic tar with sorted relative names, fixedzero timestamps/uid/gid and fixed regular modes, gzip mtime0. Keep prior archives locally as distinct immutable epochs. Extract independently to a fresh directory; check exact complete member set, every hash/count/size and original39 donor bytes and old49 bytes. Small outer README states pins, actual results, failures/limits and complete archive SHA. No raw JSON/TS evidence staging susceptible to formatting. Obtain root/Astra review of exact sealed/staged scope before any normal hooks/commit/fork push. No public request/comment/PR head/HOLD/queue action without separate explicit authorization.
